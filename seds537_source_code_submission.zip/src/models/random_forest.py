"""Random Forest baseline."""

from __future__ import annotations

from sklearn.ensemble import RandomForestClassifier


def build_random_forest(random_state: int = 42) -> RandomForestClassifier:
    """Build a Random Forest hallucination classifier."""

    return RandomForestClassifier(
        n_estimators=300,
        random_state=random_state,
        n_jobs=-1,
        class_weight="balanced",
    )


def train_random_forest(X_train, y_train, random_state: int = 42) -> RandomForestClassifier:
    """Train a Random Forest hallucination detector."""

    model = build_random_forest(random_state=random_state)
    model.fit(X_train, y_train)
    return model
